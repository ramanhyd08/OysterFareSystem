package com.demo.travelcardsystem.constant;

public enum Zone {
    ONE, TWO, THREE;
}
